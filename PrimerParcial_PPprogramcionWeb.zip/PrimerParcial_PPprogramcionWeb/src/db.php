<?php
class Conexion {
    private $host = "localhost";
    private $user = "root"; // Cambiar si tu MySQL tiene otra configuración
    private $pass = "";     
    private $db = "agencia_autos";
    private $conexion;

    public function conectar() {
        try {
            // Instanciamos el objeto PDO para la conexión
            $this->conexion = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db, $this->user, $this->pass);
            // Configuramos PDO para que lance excepciones en caso de error
            $this->conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $this->conexion;
        } catch(PDOException $e) {
            echo "Error de conexión: " . $e->getMessage();
        }
    }
}
?>