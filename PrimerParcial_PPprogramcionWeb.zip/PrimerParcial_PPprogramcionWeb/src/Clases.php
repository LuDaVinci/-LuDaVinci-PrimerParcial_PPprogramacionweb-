<?php
interface Autenticable {
    public function iniciarSesion($email, $password, $pdo);
}

// Clase Padre
abstract class Usuario implements Autenticable {
    protected $id;
    protected $nombre;
    protected $email;
    protected $rol;

    public function __construct($nombre, $email, $rol) {
        $this->nombre = $nombre;
        $this->email = $email;
        $this->rol = $rol;
    }

    public function getNombre() { return $this->nombre; }
    public function getEmail() { return $this->email; }
    public function getRol() { return $this->rol; }

    public function iniciarSesion($email, $password, $pdo) {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = :email AND password = :password");
        $stmt->execute(['email' => $email, 'password' => $password]);
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($userData) {
            if ($userData['rol'] === 'administrador') {
                return new Administrador($userData['nombre'], $userData['email']);
            } else {
                return new Empleado($userData['nombre'], $userData['email']);
            }
        }
        return false;
    }
}

// Herencia - Administrador
class Administrador extends Usuario {
    public function __construct($nombre, $email) {
        parent::__construct($nombre, $email, 'administrador');
    }
    
    public function altaEmpleado($nombre, $email, $password, $pdo) {
        $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'empleado')");
        return $stmt->execute([$nombre, $email, $password]);
    }
}

// Herencia - Empleado
class Empleado extends Usuario {
    public function __construct($nombre, $email) {
        parent::__construct($nombre, $email, 'empleado');
    }
}

// Gestión de Vehículos
class Vehiculo {
    private $id;
    private $marca;
    private $modelo;
    private $tipo; 
    private $anio;
    private $precio;
    private $imagen;
    
    private static $contadorVehiculos = 0; 

    // Constructor actualizado para recibir el tipo
    public function __construct($marca, $modelo, $tipo, $anio, $precio, $imagen = 'default_auto.png', $id = null) {
        $this->id = $id;
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->tipo = $tipo; 
        $this->anio = $anio;
        $this->precio = $precio;
        $this->imagen = $imagen;
        self::$contadorVehiculos++; 
    }

    // Getters
    public function getId() { return $this->id; }
    public function getMarca() { return $this->marca; }
    public function getModelo() { return $this->modelo; }
    public function getTipo() { return $this->tipo; } // <-- NUEVO GETTER
    public function getAnio() { return $this->anio; }
    public function getPrecio() { return $this->precio; }
    public function getImagen() { return $this->imagen; } 
    
    public static function obtenerTotalVehiculosInstanciados() {
        return self::$contadorVehiculos;
    }
}
?>