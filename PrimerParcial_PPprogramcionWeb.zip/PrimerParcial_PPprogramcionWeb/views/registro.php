<?php
session_start();
require_once '../src/db.php'; // Salimos de views y entramos a src

$error = '';
$exito = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $conexion = new Conexion();
    $pdo = $conexion->conectar();

    try {
        // Registramos al nuevo usuario como 'empleado' por defecto
        $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'empleado')");
        if ($stmt->execute([$nombre, $email, $password])) {
            $exito = "¡Registro exitoso! Ya podés iniciar sesión.";
        }
    } catch (PDOException $e) {
        $error = "Ese correo ya está registrado o hubo un error.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro - Agencia de Autos</title>
    <link rel="stylesheet" href="../assets/css/layout.css">
</head>
<body>
    <header>
        <h1>Gestión de Agencia de Autos</h1>
        <a href="../index.php">Volver al inicio</a>
    </header>

    <div class="container">
        <div class="form-container" style="max-width: 400px; margin: 0 auto;">
            <h2 style="margin-bottom: 1.5rem; text-align: center;">Registrarse</h2>
            
            <?php if($error): ?>
                <p style="color: red; text-align: center; margin-bottom: 1rem;"><?php echo $error; ?></p>
            <?php endif; ?>
            <?php if($exito): ?>
                <p style="color: green; text-align: center; margin-bottom: 1rem;"><?php echo $exito; ?></p>
            <?php endif; ?>

            <form action="registro.php" method="POST">
                <div class="form-group">
                    <label>Nombre Completo:</label>
                    <input type="text" name="nombre" required>
                </div>
                <div class="form-group">
                    <label>Correo Electrónico:</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label>Contraseña:</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-reg" style="width: 100%;">Crear Cuenta</button>
            </form>
            <div style="text-align: center; margin-top: 1rem;">
                <a href="login.php" style="color: var(--primary-color);">¿Ya tenés cuenta? Iniciá sesión acá</a>
            </div>
        </div>
    </div>
</body>
</html>