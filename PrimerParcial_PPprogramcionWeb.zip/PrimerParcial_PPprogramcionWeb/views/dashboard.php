<?php
session_start();
require_once '../src/db.php';
require_once '../src/Clases.php';

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$conexion = new Conexion();
$pdo = $conexion->conectar();

$stmt = $pdo->query("SELECT * FROM vehiculos");
$vehiculos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Gestión - Agencia</title>
    <link rel="stylesheet" href="../assets/css/layout.css">
</head>
<body>
    <header>
        <h1>Agencia de Autos - Sistema Interno</h1>
        <div>
            <span>Hola, <strong><?php echo $_SESSION['usuario']; ?></strong></span>
            <a href="../action/logout.php" class="link-logout">Cerrar Sesión</a>
        </div>
    </header>

    <?php include '../nav.php'; ?>

    <div class="container">
        
        <?php if(isset($_GET['msj'])): ?>
            <?php if($_GET['msj'] == 'guardado'): ?>
                <div class="alert-success">El vehículo se guardó correctamente.</div>
            <?php elseif($_GET['msj'] == 'actualizado'): ?>
                <div class="alert-info">El vehículo se actualizó correctamente.</div>
            <?php elseif($_GET['msj'] == 'eliminado'): ?>
                <div class="alert-danger">El vehículo ha sido eliminado del sistema.</div>
            <?php endif; ?>
        <?php endif; ?>

        <div class="form-container dashboard-form-container">
            <h2>Registrar Nuevo Vehículo</h2>
            <p class="form-subtitle">Cargá los datos e incluí una imagen clara.</p>
            
            <form action="../action/guardar.php" method="POST" enctype="multipart/form-data" class="form-row">
                <div class="form-group form-col">
                    <label>Marca:</label>
                    <input type="text" name="marca" placeholder="Ej: Toyota" required>
                </div>
                <div class="form-group form-col">
                    <label>Modelo:</label>
                    <input type="text" name="modelo" placeholder="Ej: Corolla" required>
                </div>
                <div class="form-group form-col">
                    <label>Tipo:</label>
                    <select name="tipo" required>
                        <option value="auto">Auto</option>
                        <option value="moto">Moto</option>
                    </select>
                </div>
                <div class="form-group form-col-sm">
                    <label>Año:</label>
                    <input type="number" name="anio" placeholder="2024" required>
                </div>
                <div class="form-group form-col-md">
                    <label>Precio:</label>
                    <input type="number" step="0.01" name="precio" placeholder="15000" required>
                </div>
                <div class="form-group form-col-lg">
                    <label>Imagen:</label>
                    <input type="file" name="imagen" accept="image/*">
                </div>
                
                <div class="btn-wrapper">
                    <button type="submit" class="btn btn-login">
                        Guardar Vehículo
                    </button>
                </div>
            </form>
        </div>

        <h2 class="section-title">Stock Disponible</h2>
        <table>
            <thead>
                <tr>
                    <th class="col-vista">Vista</th>
                    <th>ID</th>
                    <th>Marca</th>
                    <th>Modelo</th>
                    <th>Tipo</th>
                    <th>Año</th>
                    <th>Precio</th>
                    <th class="text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($vehiculos) > 0): ?>
                    <?php foreach($vehiculos as $v): ?>
                    <tr>
                        <td class="text-center">
                            <?php if (!empty($v['imagen']) && $v['imagen'] !== 'default_auto.png'): ?>
                                <img src="../assets/img/autos/<?php echo $v['imagen']; ?>" alt="Vehículo" class="img-tabla">
                            <?php else: ?>
                                <span class="text-sin-imagen">Sin imagen</span>
                            <?php endif; ?>
                        </td>
                        <td>#<?php echo $v['id']; ?></td>
                        <td><?php echo $v['marca']; ?></td>
                        <td><?php echo $v['modelo']; ?></td>
                        <td>
                            <?php $tipo_v = $v['tipo'] ?? 'auto'; ?>
                            <span class="badge-tipo <?php echo ($tipo_v == 'auto') ? 'badge-auto' : 'badge-moto'; ?>">
                                <?php echo strtoupper($tipo_v); ?>
                            </span>
                        </td>
                        <td><?php echo $v['anio']; ?></td>
                        <td>$<?php echo number_format($v['precio'], 2, ',', '.'); ?></td>
                        <td class="text-center">
                            <a href="editarautos.php?id=<?php echo $v['id']; ?>" class="btn-action-edit">Editar</a>
                            
                            <?php if ($_SESSION['rol'] === 'administrador'): ?>
                                <a href="../action/eliminar.php?id=<?php echo $v['id']; ?>" 
                                   class="btn-action-delete" 
                                   onclick="return confirm('¿Estás seguro que querés eliminar este vehículo?');">
                                   Eliminar
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="table-empty">No hay vehículos registrados en el sistema.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <footer class="dashboard-footer" style="text-align: center; padding: 20px; margin-top: 20px; color: #666;">
        &copy; <?php echo date('Y'); ?> - Gestión de Stock Agencia
    </footer>
</body>
</html>