<?php
session_start();
require_once '../src/db.php';
require_once '../src/Clases.php';

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'administrador') {
    header("Location: dashboard.php");
    exit();
}

$conexion = new Conexion();
$pdo = $conexion->conectar();

$stmt = $pdo->query("SELECT * FROM usuarios");
$listaUsuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios - Agencia</title>
    <link rel="stylesheet" href="../assets/css/layout.css">
</head>
<body>
    <header>
        <h1>Agencia de Autos - Personal</h1>
        <div>
            <span>Admin: <strong><?php echo $_SESSION['usuario']; ?></strong></span>
            <a href="../action/logout.php" class="link-logout">Cerrar Sesión</a>
        </div>
    </header>

    <?php include '../nav.php'; ?>

    <div class="container">
        <?php if(isset($_GET['msj'])): ?>
            <?php if($_GET['msj'] == 'actualizado'): ?>
                <div class="alert-info">El usuario ha sido actualizado correctamente.</div>
            <?php elseif($_GET['msj'] == 'eliminado'): ?>
                <div class="alert-danger">El usuario ha sido eliminado del sistema.</div>
            <?php elseif($_GET['msj'] == 'guardado'): ?>
                <div class="alert-success">Nuevo usuario registrado con éxito.</div>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(isset($_GET['error'])): ?>
            <div class="alert-danger"><?php echo htmlspecialchars($_GET['error']); ?></div>
        <?php endif; ?>

        <h2 class="section-title">Usuarios del Sistema</h2>
        
        <table>
            <thead>
                <tr>
                    <th class="col-vista text-center">Perfil</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Rol</th>
                    <th>Contraseña</th>
                    <th class="text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($listaUsuarios as $user): ?>
                <tr>
                    <td class="text-center">
                        <?php 
                        $foto = !empty($user['imagen_perfil']) ? $user['imagen_perfil'] : 'default_user.png';
                        ?>
                        <img src="../assets/img/perfiles/<?php echo $foto; ?>" alt="Perfil" class="img-perfil-tabla">
                    </td>
                    <td><?php echo htmlspecialchars($user['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td>
                        <span class="badge-rol <?php echo ($user['rol'] == 'administrador') ? 'badge-admin' : 'badge-empleado'; ?>">
                            <?php echo $user['rol']; ?>
                        </span>
                    </td>
                    <td class="password-mask">********</td>
                    <td class="text-center">
                        <a href="editarusuario.php?id=<?php echo $user['id']; ?>" class="btn-action-edit">Editar</a>
                        <a href="../action/eliminar_usuario.php?id=<?php echo $user['id']; ?>" class="btn-action-delete" onclick="return confirm('¿Estás seguro de que querés eliminar a este usuario?');">Eliminar</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>


    <footer class="dashboard-footer">
        &copy; 2026 - Administración de Personal Interno
    </footer>
</body>
</html>