<?php
session_start();
require_once '../src/db.php';
require_once '../src/Clases.php';

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'administrador') {
    header("Location: dashboard.php");
    exit();
}

$id = $_GET['id'] ?? null;
$user_edit = null;

if ($id) {
    $conexion = new Conexion();
    $pdo = $conexion->conectar();
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $user_edit = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario - Agencia</title>
    <link rel="stylesheet" href="../assets/css/layout.css">
</head>
<body>
    <header>
        <h1>Gestión de Personal</h1>
        <a href="usuarios.php" class="header-link-accent">Volver a Usuarios</a>
    </header>

    <?php include '../nav.php'; ?>

    <div class="container">
        <?php if ($user_edit): ?>
            <div class="form-container user-edit-container">
                <h2 class="edit-title">Modificar Perfil: <?php echo htmlspecialchars($user_edit['nombre']); ?></h2>
                
                <form action="../action/modificar_usuario_acc.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $user_edit['id']; ?>">
                    <input type="hidden" name="imagen_actual" value="<?php echo $user_edit['imagen_perfil']; ?>">

                    <div class="form-group">
                        <label>Nombre Completo:</label>
                        <input type="text" name="nombre" value="<?php echo htmlspecialchars($user_edit['nombre']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Email (Username):</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($user_edit['email']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Contraseña:</label>
                        <input type="text" name="password" placeholder="Dejar vacío para mantener la actual">
                    </div>

                    <div class="checkbox-group">
                        <input type="checkbox" name="rol_admin" value="1" id="rol_check" class="checkbox-custom" <?php echo ($user_edit['rol'] === 'administrador') ? 'checked' : ''; ?>>
                        <label for="rol_check">Asignar permisos de <strong>Administrador</strong></label>
                    </div>

                    <div class="edit-image-section">
                        <div class="text-center">
                            <label class="edit-image-label">Foto Actual</label>
                            <?php $foto = !empty($user_edit['imagen_perfil']) ? $user_edit['imagen_perfil'] : 'default_user.png'; ?>
                            <img src="../assets/img/perfiles/<?php echo $foto; ?>" alt="Perfil" class="user-preview-img">
                        </div>
                        
                        <div class="form-group form-col">
                            <label>Cambiar foto de perfil:</label>
                            <input type="file" name="perfil" accept="image/*">
                        </div>
                    </div>

                    <button class="btn btn-login btn-save-edit" type="submit">Actualizar Datos</button>
                </form>
            </div>
        <?php else: ?>
            <div class="error-container">
                <h2 class="error-title">404</h2>
                <p class="error-text">Usuario no encontrado.</p>
                <a href="usuarios.php" class="btn btn-reg btn-error-back">Volver a la lista</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>