<?php
session_start();
// Subimos un nivel para encontrar src/
require_once '../src/db.php';
require_once '../src/Clases.php';

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $conexion = new Conexion();
    $pdo = $conexion->conectar();

    $auth = new Empleado("", ""); 
    $usuarioLogueado = $auth->iniciarSesion($email, $password, $pdo);

    if ($usuarioLogueado) {
        $_SESSION['usuario'] = $usuarioLogueado->getNombre();
        $_SESSION['rol'] = $usuarioLogueado->getRol();
        // dashboard.php está en la misma carpeta views/, así que no necesita ruta extra
        header("Location: dashboard.php"); 
        exit();
    } else {
        $error = "Credenciales incorrectas.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - Agencia de Autos</title>
    <link rel="stylesheet" href="../assets/css/layout.css">
</head>
<body>
    <header>
        <h1>Gestión de Agencia de Autos</h1>
        <a href="../index.php">Volver al inicio</a>
    </header>

    <div class="container">
        <div class="form-container" style="max-width: 400px; margin: 0 auto;">
            <h2 style="margin-bottom: 1.5rem; text-align: center;">Iniciar Sesión</h2>
            <?php if($error): ?>
                <p style="color: red; text-align: center; margin-bottom: 1rem;"><?php echo $error; ?></p>
            <?php endif; ?>
            <form action="login.php" method="POST">
                <div class="form-group">
                    <label>Correo Electrónico:</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label>Contraseña:</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-login" style="width: 100%;">Ingresar</button>
            </form>
        </div>
    </div>
</body>
</html>