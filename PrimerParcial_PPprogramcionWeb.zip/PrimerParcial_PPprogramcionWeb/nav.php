<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<nav class="main-nav">
    <div class="nav-container">
        <ul class="nav-list">
            <li><a href="dashboard.php" class="nav-link">Vehículos</a></li>
            
            <?php if(isset($_SESSION['rol']) && $_SESSION['rol'] === 'administrador'): ?>
                <li><a href="usuarios.php" class="nav-link">Usuarios</a></li>
                <!-- <li><a href="logs.php" class="nav-link">Logs</a></li> -->
            <?php endif; ?>
        </ul>
    </div>
</nav>