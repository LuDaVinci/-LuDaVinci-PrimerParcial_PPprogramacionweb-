<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agencia de Autos</title>
    <link rel="stylesheet" href="assets/css/layout.css">
</head>
<body>
    <div class="splash-container">
        <div class="splash-header">
            <a href="views/registro.php" class="btn btn-reg btn-link">Registrarse</a>
            <a href="views/login.php" class="btn btn-login btn-link">Iniciar Sesión</a>
        </div>
    </div>
</body>
</html>