<?php
session_start();
require_once '../src/db.php';
require_once '../src/Clases.php';

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'administrador') {
    header("Location: ../views/dashboard.php");
    exit();
}

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id_usuario = $_GET['id'];

  
    if (isset($_SESSION['id_usuario_db']) && $id_usuario == $_SESSION['id_usuario_db']) {
        header("Location: ../views/usuarios.php?error=No podés eliminar tu propia cuenta");
        exit();
    }

    try {
        $conexion = new Conexion();
        $pdo = $conexion->conectar();

        $stmtFoto = $pdo->prepare("SELECT imagen_perfil FROM usuarios WHERE id = :id");
        $stmtFoto->execute([':id' => $id_usuario]);
        $usuario = $stmtFoto->fetch(PDO::FETCH_ASSOC);

        if ($usuario) {
            $foto = $usuario['imagen_perfil'];
            if ($foto !== 'default_user.png' && file_exists("../assets/img/perfiles/" . $foto)) {
                unlink("../assets/img/perfiles/" . $foto);
            }

            $stmtDel = $pdo->prepare("DELETE FROM usuarios WHERE id = :id");
            $stmtDel->execute([':id' => $id_usuario]);

            header("Location: ../views/usuarios.php?msj=eliminado");
            exit();
        } else {
            header("Location: ../views/usuarios.php?error=Usuario no encontrado");
        }

    } catch (PDOException $e) {
        header("Location: ../views/usuarios.php?error=No se pudo eliminar: El usuario tiene registros asociados");
    }
} else {
    header("Location: ../views/usuarios.php");
}
?>