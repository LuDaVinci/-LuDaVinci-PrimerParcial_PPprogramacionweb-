<?php
session_start();
require_once '../src/db.php';
require_once '../src/Clases.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conexion = new Conexion();
    $pdo = $conexion->conectar();

    $id = $_POST['id'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $tipo = $_POST['tipo']; // NUEVO
    $anio = $_POST['anio'];
    $precio = $_POST['precio'];
    $imagenActual = $_POST['imagen_actual'];

    $nombreImagen = $imagenActual;
    if (isset($_FILES['nueva_imagen']) && $_FILES['nueva_imagen']['error'] === UPLOAD_ERR_OK) {
        $nombreImagen = uniqid('auto_') . "." . pathinfo($_FILES['nueva_imagen']['name'], PATHINFO_EXTENSION);
        move_uploaded_file($_FILES['nueva_imagen']['tmp_name'], "../assets/img/autos/" . $nombreImagen);
        if ($imagenActual !== 'default_auto.png') unlink("../assets/img/autos/" . $imagenActual);
    }

    try {
        $stmt = $pdo->prepare("UPDATE vehiculos SET marca = :marca, modelo = :modelo, tipo = :tipo, anio = :anio, precio = :precio, imagen = :imagen WHERE id = :id");
        $stmt->execute([
            ':marca' => $marca,
            ':modelo' => $modelo,
            ':tipo' => $tipo,
            ':anio' => $anio,
            ':precio' => $precio,
            ':imagen' => $nombreImagen,
            ':id' => $id
        ]);
        header("Location: ../views/dashboard.php?msj=actualizado");
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}