<?php
session_start();
require_once '../src/db.php';
require_once '../src/Clases.php';

// Seguridad: Solo administradores
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'administrador') {
    header("Location: ../views/dashboard.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conexion = new Conexion();
    $pdo = $conexion->conectar();

    $nombre = htmlspecialchars($_POST['nombre']);
    $email = htmlspecialchars($_POST['email']);
    $password = $_POST['password']; 
    $rol = isset($_POST['rol_admin']) ? 'administrador' : 'empleado';
    
    $nombreImagen = "default_user.png"; 

    if (isset($_FILES['perfil']) && $_FILES['perfil']['error'] === UPLOAD_ERR_OK) {
        if (str_starts_with($_FILES['perfil']['type'], "image/")) {
            $ext = pathinfo($_FILES['perfil']['name'], PATHINFO_EXTENSION);
            $nombreImagen = uniqid('user_') . "." . $ext;
            move_uploaded_file($_FILES['perfil']['tmp_name'], "../assets/img/perfiles/" . $nombreImagen);
        }
    }

    try {
        $sql = "INSERT INTO usuarios (nombre, email, password, rol, imagen_perfil) 
                VALUES (:nombre, :email, :password, :rol, :imagen)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':nombre' => $nombre,
            ':email' => $email,
            ':password' => $password,
            ':rol' => $rol,
            ':imagen' => $nombreImagen
        ]);

        header("Location: ../views/usuarios.php?msj=guardado");
        exit();
    } catch (PDOException $e) {
        die("Error al guardar: " . $e->getMessage());
    }
}