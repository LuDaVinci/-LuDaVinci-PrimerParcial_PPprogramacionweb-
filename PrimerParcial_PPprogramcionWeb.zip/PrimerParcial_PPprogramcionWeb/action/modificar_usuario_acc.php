<?php
session_start();
require_once '../src/db.php';
require_once '../src/Clases.php';

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'administrador') {
    header("Location: ../views/dashboard.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conexion = new Conexion();
    $pdo = $conexion->conectar();

    $id = $_POST['id'];
    $nombre = htmlspecialchars($_POST['nombre']);
    $email = htmlspecialchars($_POST['email']);
    $rol = isset($_POST['rol_admin']) ? 'administrador' : 'empleado';
    $imagenActual = $_POST['imagen_actual'];
    
    $sql_pass = "";
    $params = [':nombre' => $nombre, ':email' => $email, ':rol' => $rol, ':id' => $id];

    if (!empty($_POST['password'])) {
        $sql_pass = ", password = :password";
        $params[':password'] = $_POST['password'];
    }

    $nombreImagen = $imagenActual; 

    if (isset($_FILES['perfil']) && $_FILES['perfil']['error'] === UPLOAD_ERR_OK) {
        if (str_starts_with($_FILES['perfil']['type'], "image/")) {
            $ext = pathinfo($_FILES['perfil']['name'], PATHINFO_EXTENSION);
            $nombreImagen = uniqid('user_') . "." . $ext;
            $rutaDestino = "../assets/img/perfiles/" . $nombreImagen;

            if (move_uploaded_file($_FILES['perfil']['tmp_name'], $rutaDestino)) {
                if ($imagenActual !== 'default_user.png' && file_exists("../assets/img/perfiles/" . $imagenActual)) {
                    unlink("../assets/img/perfiles/" . $imagenActual);
                }
            }
        }
    }
    
    $params[':imagen'] = $nombreImagen;

    try {
        $query = "UPDATE usuarios SET nombre = :nombre, email = :email, rol = :rol, imagen_perfil = :imagen $sql_pass WHERE id = :id";
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);

        header("Location: ../views/usuarios.php?msj=actualizado");
        exit();
    } catch (PDOException $e) {
        die("Error en DB: " . $e->getMessage());
    }
}