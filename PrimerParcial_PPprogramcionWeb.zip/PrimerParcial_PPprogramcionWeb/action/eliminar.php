<?php
session_start();
require_once '../src/db.php';
require_once '../src/Clases.php';

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'administrador') {
    header("Location: ../views/dashboard.php");
    exit();
}

$id = $_GET['id'] ?? null;

if ($id) {
    $conexion = new Conexion();
    $pdo = $conexion->conectar();

    try {
        
        $stmtImg = $pdo->prepare("SELECT imagen FROM vehiculos WHERE id = :id");
        $stmtImg->execute(['id' => $id]);
        $auto = $stmtImg->fetch(PDO::FETCH_ASSOC);

        
        if ($auto && !empty($auto['imagen']) && $auto['imagen'] !== 'default_auto.png') {
            $rutaImagen = '../assets/img/autos/' . $auto['imagen'];
            if (file_exists($rutaImagen)) {
                unlink($rutaImagen); // Borra el archivo físico
            }
        }

    
        $stmt = $pdo->prepare("DELETE FROM vehiculos WHERE id = :id");
        $stmt->execute(['id' => $id]);

        
        header("Location: ../views/dashboard.php?msj=eliminado");
        exit();

    } catch (PDOException $e) {
        echo "Error al eliminar el vehículo: " . $e->getMessage();
    }
} else {
    header("Location: ../views/dashboard.php");
    exit();
}
?>