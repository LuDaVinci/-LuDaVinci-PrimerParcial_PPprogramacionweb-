<?php
session_start();
require_once '../src/db.php';
require_once '../src/Clases.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conexion = new Conexion();
    $pdo = $conexion->conectar();

    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $tipo = $_POST['tipo']; // NUEVO
    $anio = $_POST['anio'];
    $precio = $_POST['precio'];
    
    $nombreImagen = "default_auto.png";
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $nombreImagen = uniqid('auto_') . "." . pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION);
        move_uploaded_file($_FILES['imagen']['tmp_name'], "../assets/img/autos/" . $nombreImagen);
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO vehiculos (marca, modelo, tipo, anio, precio, imagen) VALUES (:marca, :modelo, :tipo, :anio, :precio, :imagen)");
        $stmt->execute([
            ':marca' => $marca,
            ':modelo' => $modelo,
            ':tipo' => $tipo,
            ':anio' => $anio,
            ':precio' => $precio,
            ':imagen' => $nombreImagen
        ]);
        header("Location: ../views/dashboard.php?msj=guardado");
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}